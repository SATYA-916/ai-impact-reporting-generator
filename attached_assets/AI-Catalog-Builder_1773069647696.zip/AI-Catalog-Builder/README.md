# AI Impact Reporting Generator

An intelligent full-stack application that calculates sustainability impact for eco-friendly purchases and generates AI-powered impact reports using Google Gemini.

## 🚀 Features

- **Product Catalog**: Browse curated eco-friendly products with impact metrics
- **Impact Calculator**: Calculate plastic saved and carbon avoided based on quantity
- **AI-Powered Reports**: Generate human-readable sustainability impact statements using Gemini 2.5 Flash
- **Clean UI**: Modern, minimal eco-friendly design with confetti celebrations

## 🛠️ Tech Stack

- **Frontend**: React + TypeScript, Vite, TailwindCSS, Framer Motion
- **Backend**: Node.js + Express
- **Database**: MongoDB
- **AI**: Google Gemini 2.5 Flash API

## 📋 Setup Instructions

### 1. Environment Variables

Add the following environment variables to your Replit project's Secrets tab:

```
MONGO_URI=mongodb+srv://zywu801:Satya123@cluster0.t47bcbv.mongodb.net/ai_catalog?retryWrites=true&w=majority
GEMINI_API_KEY=AIzaSyBt8bwA_DTfEPBojAe6FHEY5CfFL3ayjoY
```

### 2. Install Dependencies

Dependencies are already installed. If needed, run:

```bash
npm install
```

### 3. Start the Application

```bash
npm run dev
```

The application will start at `http://localhost:5000`

## 🔌 API Endpoints

### Get Products
```
GET /api/products
```
Returns an array of available eco-products with their impact metrics.

**Response:**
```json
[
  {
    "id": "product-id",
    "name": "Compostable Food Packaging Box",
    "plasticSavedPerUnit": 15,
    "carbonSavedPerUnit": 0.03,
    "source": "local"
  }
]
```

### Generate Impact Report
```
POST /api/impact-report
Content-Type: application/json

{
  "productId": "product-id",
  "quantity": 100
}
```

**Response:**
```json
{
  "product_name": "Compostable Food Packaging Box",
  "quantity": 100,
  "plastic_saved_kg": 1.5,
  "carbon_avoided_kg": 3,
  "impact_statement": "This purchase helped avoid approximately 1.5 kg of plastic waste and reduced carbon emissions by around 3 kg CO₂."
}
```

## 📊 Database Schema

### ecoProducts Collection

Each eco-product document contains:
- `name` (String): Product name
- `plastic_saved_per_unit` (Number): Plastic saved in grams per unit
- `carbon_saved_per_unit` (Number): Carbon avoided in kg per unit
- `source` (String): "local" or "imported"

## 🎯 How It Works

1. **Product Selection**: User selects an eco-friendly product from the dropdown
2. **Quantity Input**: User enters the desired quantity
3. **Impact Calculation**: 
   - Plastic saved = plastic_saved_per_unit × quantity ÷ 1000 (converted to kg)
   - Carbon avoided = carbon_saved_per_unit × quantity
4. **AI Generation**: The data is sent to Gemini 2.5 Flash to generate a compelling impact statement
5. **Display Results**: Beautiful card displays all metrics with celebration animation

## 🔒 Security Notes

- API keys are stored in Replit environment secrets (not in .env file)
- All sensitive data is kept server-side
- Frontend makes requests to backend endpoints only

## 📝 Example Products (Auto-Seeded)

1. **Compostable Food Packaging Box**
   - Plastic saved: 15g per unit
   - Carbon avoided: 0.03 kg per unit
   - Source: local

2. **Bamboo Toothbrush**
   - Plastic saved: 10g per unit
   - Carbon avoided: 0.01 kg per unit
   - Source: imported

3. **Reusable Shopping Bag**
   - Plastic saved: 50g per unit
   - Carbon avoided: 0.1 kg per unit
   - Source: local

## 🚀 Deployment

The app is ready to deploy! You can publish it to make it live and accessible anywhere.

## 📄 License

MIT
